package chat.message;

public enum MessageType { LOGIN, MESSAGE }
